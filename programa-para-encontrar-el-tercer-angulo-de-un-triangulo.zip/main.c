
#include <stdio.h>

int main()
{
    printf("* * * *Programa para encontrar el tercer angulo de un numero * * * * *\nIngresa el primer angulo del triangulo: ");
    int a, b, c;
    scanf("%d", &a);
    if (a<1)
        printf("Numero invalido\n");
    else if(a>179)
        printf("Numero invalido\n");
    else
    printf("Ingresa el segundo angulo: \n");
    scanf("%d", &b);
    if (b<1)
        printf("Numero invalido\n");
    else if(b>179)
        printf("Numero invalido\n");
    else
        c = 180-(a+b);
        if (c>180)
            printf("La suma de los angulos de un triangulo debe ser de 180 grados\nUno de tus angulos es incorrecto");
        else if (c<=0)
            printf("La suma de los angulos de un triangulo no pueden ser menor o igual a 0");
        else
        printf("El tercer angulo del triangulo tiene: %d grados", c);
    return 0;
}


