#include <stdio.h>

int main()
{
    int edad;
    int FDN;
    
    printf("Cual es tu edad?");
    scanf("%d", &edad);
    
    printf("En que ano naciste?");
    scanf("%d", &FDN);
    
    printf("Tu edad es:%d\t\n", edad);
    printf("Tu fecha de nacimiento es: %d\t\n", FDN);
    
    return 0;
    
}