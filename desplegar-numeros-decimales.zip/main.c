#include <stdio.h>
int main()
{
    float numdeci;
    printf("Introduzca un numero decimal: ");
    scanf("%f", &numdeci);
    
    printf("\n El numero con decimal es: %.3f ", numdeci);
    
    return 0;
}