#include <stdio.h>

int main()
{
    printf("\tPrograma para calcular la circunferencia de un circulo\t\nIngresa el radio del circulo:\t");
    float r, C;
    scanf("%f", &r);
    C= 2 *(3.1416 * r);
    printf("La circunferencia del circulo es:\t%.2f", C);
    return 0;
    
}