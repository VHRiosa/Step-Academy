#include <stdio.h>

int main()
{
    printf("Programa para desplegar el mes que corresonde a un numero del uno al doce\n ingresa un numero del 1 al 12: ");
    int x;
    scanf("%d", &x);
    if (x<1)
        printf("numero invalido");
    else if (x>12)
        printf("Numero invalido");
    else if(x=1)
        printf("El mes que corresponde al mes %d es enero", x);
    else if(x=2)
        printf("El mes que corresponde al mes %d es febrero",x);
    else if(x=3)
        printf("El mes que corresponde al mes %d es marzo",x);        
    else if(x=4)
        printf("El mes que corresponde al mes %d es abril",x);
    else if(x=5)
        printf("El mes que corresponde al mes %d es mayo",x);
    else if(x=6)
        printf("El mes que corresponde al mes %d es junio",x);
    else if(x=7)
        printf("El mes que corresponde al mes %d es julio",x);
    else if(x=8)
        printf("El mes que corresponde al mes %d es agosto",x);
    else if(x=9)
        printf("El mes que corresponde al mes %d es septiembre",x);        
    else if(x=10)
        printf("El mes que corresponde al mes %d es octubre",x);
    else if(x=11)
        printf("El mes que corresponde al mes %d es noviembre",x);
    else if(x=12)
        printf("El mes que corresponde al mes %d es diciembre",x);
       
    return 0;
    
}
