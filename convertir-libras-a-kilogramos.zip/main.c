#include <stdio.h>
int main()
{
    printf("\tPrograma para convertir libras a kilos\n\tIngresa la cantidad de libras que quieres convertir a kilogramos: ");
    float l, r;
    scanf("%f", &l);
    r=l*2.20462;
    printf("\t%.2f libras es igual a %.2f kilogramos.", l, r);
    return 0;
}