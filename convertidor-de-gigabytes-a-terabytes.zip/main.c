#include <stdio.h>

int
main ()
{
  /*int a = 1024; */
  int var, r;

  printf ("programa para convertir terabytes a gigabytes\n");
  printf ("Cuantos gigabytes quieres convertir a terabytes?\n");
  scanf ("%d", &var);
  r = var * 1024;
  printf ("el resutado es:%d\n", r);
  return 0;
}
