#include <stdio.h>

int main()
{
    printf("\tprograma para calcular cuantas horas, minutos y segundos tiene una cantidad determinada de dias.\n\tIgresa la cantidad de dias:\t");
    float d, h, m, s;
    scanf("%f", &d);
    h=d*24;
    m=d*(24*60);
    s=d*24*60*60;
    printf("\t%.2f dias contiene %.2f horas, %.2f, minutos, %.2f segundos", d, h, m, s);
    return 0;
}
