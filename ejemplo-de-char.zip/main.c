#include <stdio.h>

int main()
{
    char nombre[20];
    
    printf("Introuduzca su nombre: ");
    scanf("%s", nombre);
    printf("Hola %s, buenos dC-as", nombre);
    return 0;
}