#include <stdio.h>
int main()
{
    printf("* * * Calculadora * * *\nEsta calculadora trabaja con numeros enteros\ny realiza las operaciones de:\n1.-Suma\n2.-Resta\n3.-Multiplicacion\n4.-Division\nIngresa una opcion del 1 al 4: ");
    int opcion, a, b;
    scanf("%d", &opcion);
    switch(opcion)
    {
        case 1 :
            printf("* * * Suma de dos numeros * * *\nIngresa el primer numero: ");
            scanf("%d", &a);
            printf("Ingresa el segundo numero: ");
            scanf("%d", &b);
            printf("El resultado de la suma es %d", a+b);
        break;
        case 2 :
            printf("* * * Resta de dos numeros * * *\nIngresa el primer numero: ");
            scanf("%d", &a);
            printf("Ingresa el segundo numero: ");
            scanf("%d", &b);
            printf("El resultado de la resta es %d", a-b);
        break;
        case 3 :
            printf("* * * Multiplicacion de dos numeros * * *\nIngresa el primer numero: ");
            scanf("%d", &a);
            printf("Ingresa el segundo numero: ");
            scanf("%d", &b);
            printf("El resultado de la multiplicacion es %d", a*b);
        break;
        case 4 :
            printf("* * * Division de dos numeros * * *\nIngresa el primer numero: ");
            scanf("%d", &a);
            printf("Ingresa el segundo numero: ");
            scanf("%d", &b);
            printf("El resultado de la division es %d", a/b);
        break;
        default :
            printf("Opcion invalida");
        
    }
        return 0;
        
}
