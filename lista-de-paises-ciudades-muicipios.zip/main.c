
#include <stdio.h>

int main()
{
    printf("Paises\n\tSri Lanka\n\tSenegal\n\tLatvia\n");
    printf("Ciudades\n\tMogadishu\n\tGeorgia\n\tKuala Lumpur\n");
    printf("Municipios\n\tEcatepec\n\tRosarito\n\tEnsenada\n");

    return 0;
}
