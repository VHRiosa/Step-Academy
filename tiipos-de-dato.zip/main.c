#include <stdio.h>

int main()
{
    int num1;
    int num2;
    int resultado;
    
    printf("Ingrese el primer valor\n");
    scanf("%d", &num1); /*lee el valor ingresado y lo guarda*/
    
    printf("Ingrese el segundo valor\n");
    scanf("%d", &num2); /* d- Entero o decimal  - tipo de dato*/
    
    resultado=num1+num2;
    
    printf("El resultado de la suma es: %d\n",resultado);
    return 0;
    
    
}