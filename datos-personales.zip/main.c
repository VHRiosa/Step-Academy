#include <stdio.h>

int main()
{
printf("Victor Hugo Rios Adame\n");
printf("Ciudad de Mexico\n");
printf("Cotizador\n");
return 0;
}
