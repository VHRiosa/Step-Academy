#include <stdio.h>

int main()
{
	printf("* * * Programa para encontrar el mayor de tres numeros * * *\nIngresa tres numeros: ");
	double n1, n2, n3;
	scanf("%lf %lf %lf", &n1, &n2, &n3);
	if ( n1>=n2 && n1>=n3 )
		printf("El numero %.1f es mayor", n1);
	if ( n2>=n1 && n2>=n3 )
		printf("El numero %.1f es mayor", n2);
	if ( n3>=n1 && n3>=n2 )
		printf("El numero %.1f es mayor", n3);

return 0;
}
