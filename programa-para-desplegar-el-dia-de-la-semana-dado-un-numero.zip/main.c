#include <stdio.h>

int main()
{
    printf("Programa para desplegar que dia de la semana es un numero de uno a siete\nIngresa un numero de uno a siete: ");
    int x;
    scanf("%d", &x);
    if(x<1)
        printf("Numero invalido");
    else if(x>7)
        printf("Numero invalido");
    else if(x==1)
        printf("El dia es lunes");
    else if(x==2)
        printf("El dia es martes");    
    else if(x==3)
        printf("El dia es miercoles");
    else if(x==4)
        printf("El dia es jueves");
    else if(x==5)
        printf("El dia es viernes");
    else if(x==6)
        printf("El dia es sabado");
    else if(x==7)
        printf("El dia es domingo");

        
    
    return 0;
}