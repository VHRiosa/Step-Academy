#include <stdio.h>

int main()
{
    printf("programa de convercion de pesos a dolares euros a dolares y dolares a yenes\n\n");
    printf("Ingresa la cantidad de pesos que quieres convertir:\n");
    float p, r, te=1.13, ty=109.78 ,e ,y;
    scanf("%f", &p);
    printf("Introduce el tipo de cambio\n");
    float t;
    scanf("%f", &t);
    r=p*t;
    printf("La cantidad de dolares es: %.2f\n\n", r);
    printf("Ahora a convertir dolares a euros\n\n");
    printf("Introduce la cantidad de euros que quieres convertir a dolares: \n");
    scanf("%f", &e);
    r=te*e;
    printf("La cantidad de euros es:\t%.2f\n\n", r);
    printf("Ahora a convertir dolares a yenes\n\nIngresa la cantidad de dolares que quieres convertir:\n");
    scanf("%f", &y);
    r=y*ty;
    printf("La cantidad de yenes es: %.2f", r);
    
    
    
    return 0;
}