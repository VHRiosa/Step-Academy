
#include <stdio.h>

int main()
{
    printf("programa para saber entre que rango de numeros entra la suma de dos numeros.\nRANGOS:\n\t1-100\n\t101-500\n\t501-1000\n\t>1000\n");
    printf("ingresa el primer numero: ");
    int r, x, y;
    scanf("%d", &x);
    printf("ingresa el segundo numero: ");
    scanf("%d", &y);
    r=x+y;
    if(r<1)
        printf("El numero es menor a 1");
    else if(r>1000)
        printf("El numero es mayor a 1000");
    else if(r<=100)
        printf("El numero esta dentro del rango 1 - 100");
    else if(r<=500)
        printf("El numero esta dentro del rango 101 - 500");
    else if(r<=1000)
        printf("El numero esta dentro del rango 501 - 1000");

    return 0;
}

