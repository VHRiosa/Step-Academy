#include <stdio.h>

int main ()
{
    int numero;
    
    printf("\n Introduzca un numero: ");
    scanf("%d", &numero);
    if(numero>=100)
    
     printf("\n     Es mayor o igual a 100");   
     else
     printf("\n     Es menor a 100");
     
     return 0;
    
    
}