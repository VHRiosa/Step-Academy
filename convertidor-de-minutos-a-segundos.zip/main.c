#include <stdio.h>

int main()
{
    int x, r;
    printf("Programa para convertir minutos a segundos\n");
    printf("Cuantos minutos quieres convertir a segundos?\n");
    scanf("%d", &x);
    r=x*60;
    printf("El resultado es:%d\n", r);
    return 0;
    
}
