#include <stdio.h>

int main ()
{
    printf("Programa para saber si una persona es mayor de edad\nIntroduce la edad del individuo: ");
    int x;
    scanf("%d", &x);
    if(x<0)
            printf("Edad invalida");
    else if(x<5)
        printf("El individuo es menor de cinco anios");
        
    else if (x<=13)
        printf("El individuo esta en la ninez");
        
    else if (x<=17)
        printf("El individuo adolescente");
        
    else if (x<=35)
        printf("El individuo es Adulto Joven");
        
    else if (x<=64)
        printf("El individuo es adulto");
        
    else if (x>64)
        printf("El individuo es adulto mayor");



    return 0;
    
}