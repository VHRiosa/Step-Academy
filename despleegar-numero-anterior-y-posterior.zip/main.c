#include <stdio.h>

int main()
{

    printf("Programa para mostrar el numero anterior y el posterior de un numero\nIngresa un numero: ");
    int v;
    scanf("%d", &v);
    
    printf("El numero anterior es:%d\n", v-1);
    
    printf("El numero posterior es:%d ",v+1);
    return 0;
    
}

