#include <stdio.h>

int main()
{
    int num1, resultado;
    int a=18;
    printf("ingrese el primer valor\n");
    scanf("%d", &num1);
    resultado=a*num1;
    printf("el reslutado es:%d\n", resultado);
    return 0;
    
}