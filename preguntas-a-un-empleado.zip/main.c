#include <stdio.h>

int main()
{
    char r1[20];
    char r2[20];
    char r3[20];
    int r4;
    int r5;
    
    printf("CuC%l es tu nombre:\n");
    scanf("%s", r1);
    printf("En que ciudad naciste?:\n");
    scanf("%s", r2);
    printf("CC3mo se llama tu madre?:\n");
    scanf("%s", r3);
    printf("QuC) edad tienes?:\n");
    scanf("%d", &r4);
    printf("CuC%ntos hijos tienes?:\n");
    scanf("%d", &r5);
    
    printf("Tu nombre es: %s\n", r1);
    printf("Tu ciudad natal es: %s\n", r2);
    printf("El nombre de tu madre es: %s\n", r3);
    printf("Tu edad es: %d\n", r4);
    printf("El nC:mero de hijos que tienes es: %d\n", r5);
    
    return 0;
    
    
}