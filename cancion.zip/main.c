#include <stdio.h>

int main()
{
    printf("\nThe less I know the better");
    printf("\n\n");    
    printf("Someone said they live together\nI ran out the door to get her\nShe was holding hands with Trevor\nNot the greatest feeling ever\nSaid pull yourself together\nYou should try your luck with Heather\nAnd I hope they slept together\nOh the less I know the better\nThe less I know the better\n\n\n");
    printf("Oh my love, can't you see yourself by my side\nNo surprise when you're on his shoulder like every night\nOh my love, can't you see a child on my mind\nDon't suppose we could convince your lover to change his mind\nSo goodbye\n\n\n");
    printf("She said it's not now or never\nWaiting years we'll be together\nI said better late than never\nJust don't make me wait forever\nDon't make me wait forever\nDon't make me wait forever\n\n\n");
    printf("Oh my love, can't you see yourself by my side\nI don't...\n\n\n");
    printf("Artista - Tame Impala");
    return 0;
}
